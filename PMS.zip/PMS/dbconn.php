<?php
    $conn=mysqli_connect("localhost","root","","pms");
    if(mysqli_connect_errno()){
        die('Database Connection Error:'.mysqli_connect_error());
    }
?>