<?php
   require 'account.php';

    if(isset($_POST['update'])){
        $f_name=mysqli_real_escape_string($conn,$_POST['f_name']);
        $l_name=mysqli_real_escape_string($conn,$_POST['l_name']);
        $initial=mysqli_real_escape_string($conn,$_POST['initial']);
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $dob=mysqli_real_escape_string($conn,$_POST['dob']);
        $phone=mysqli_real_escape_string($conn,$_POST['phone']);
        $age=mysqli_real_escape_string($conn,$_POST['age']);
        $role=mysqli_real_escape_string($conn,$_POST['role']);
        $id=$row['id'];
        $query="UPDATE credentials SET f_name='$f_name',l_name='$l_name',initial='$initial',
        email='$email',dob='$dob',age='$age',role='$role' WHERE id='$id'";
        $query_run=mysqli_query($conn,$query);
        if($query_run){
            $_SESSION['message']="Profile Updated Successfully ";
            header("Location:login1.php");
            exit(0);
        }
        else{
            $_SESSION['message']="Profile Not Updated Successfully";
            header("Location:index.php");
            exit(0);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-success">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card  o-hidden my-5">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <div class="h1 text-success mb-4"><b>Edit Task</b></div>
                                    </div>
                                    <form action=""class="user"method="post">
                                                    <div class="row">
                                                        <div class="form-group col-md-5"> 
                                                            First Name
                                                            <input type="text" class="form-control"name="f_name"value="<?= $row['f_name']?>">
                                                        </div>
                                                        <div class="form-group col-md-5">
                                                            Last Name
                                                            <input type="text" class="form-control"name="l_name"value="<?= $row['l_name']?>">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            Initial
                                                            <input type="text" class="form-control"name="Initial"value="<?= $row['initial']?>">
                                                        </div>
                                                        <div class="form-group col-md-8">
                                                            Email-id
                                                            <input type="em" class="form-control" name="email"value="<?= $row['email']?>">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            Date of Birth
                                                            <input type="date" min="" class="form-control"name="dob"value="<?= $row['dob']?>">
                                                        </div>
                                                        <div class="form-group col-md-6">
                                                            Phone no
                                                            <input type="number" min="" class="form-control " name="phone"value="<?= $row['phone']?>">
                                                        </div>
                                                        <div class="form-group col-md-2">
                                                            Age
                                                            <input type="number" min="" class="form-control "name="age"value="<?= $row['age']?>">
                                                        </div>
                                                        <div class="form-group col-md-4">
                                                            Role
                                                            <select id="inputState" class="form-control"name="role"value="<?= $row['role']?>">
                                                              <option selected>Student</option>
                                                              <option>Employee</option>
                                                              <option>Enterprenur</option>
                                                              <option>Non-Employee</option>
                                                              <option>Others</option>
                                                            </select>
                                                          </div>
                                                          
                                                        <div class="col-md-4"></div>
                                                        <div class="col-md-4">
                                                            <button type="submit"class="btn btn-primary btn-user btn-block"name="update">
                                                                Update</Button>
                                                        </div>

                                                        <div class="col-md-4"></div>
                                                    </div>
                                        
                                    </form>
                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>




     <!-- Bootstrap core JavaScript-->
     <script src="vendor/jquery/jquery.min.js"></script>
     <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 
     <!-- Core plugin JavaScript-->
     <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
 
     <!-- Custom scripts for all pages-->
     <script src="js/sb-admin-2.min.js"></script>
    
</body>
</html>