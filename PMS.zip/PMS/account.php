<?php
session_start();
require 'dbconn.php';
if(!empty($_SESSION['mail'])){
    $email=mysqli_real_escape_string($conn,$_SESSION['mail']);
    $result=mysqli_query($conn,"SELECT * FROM credentials WHERE email = '$email'");
    $row=mysqli_fetch_assoc($result);
}
else{
    header("Location:login.php");
}


?>