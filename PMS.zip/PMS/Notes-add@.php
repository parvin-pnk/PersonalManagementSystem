<?php
    session_start();
    require 'dbconn.php';
    if(isset($_POST['add-notes'])){
        $level=mysqli_real_escape_string($conn,$_POST['level']);
        $title=mysqli_real_escape_string($conn,$_POST['title']);
        $notes=mysqli_real_escape_string($conn,$_POST['notes']);
    }
    $query="INSERT INTO notes(level,title,notes)VALUES('$level','$title','$notes')";
    $check=mysqli_query($conn,$query);

    if($check){
        $_SESSION['message']="Notes added Successfully";
        header("Location:Notes-add.php");
        exit(0);
    }
    else{
        $_SESSION['message']="Notes Not added";
        header("Location:Notes-add.php");
        exit(0);

    }



?>