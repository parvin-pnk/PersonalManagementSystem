<?php
    session_start();
    require 'dbconn.php';
    if(isset($_POST['login'])){
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $pass=mysqli_real_escape_string($conn,$_POST['password']);
        

        $query="SELECT * FROM credentials WHERE email='$email' AND pass='$pass'";
        $result=mysqli_query($conn,$query);
       // $row=mysqli_fetch_assoc($result);
        $count=mysqli_num_rows($result);
        echo $count;
        if($count > 0){
            $_SESSION['mail']=$email;
            header("Location:index.php");    
        }
        else{
            echo "<script> alert('Login Credentials doesnot match ,Create Account !');</script>";
                  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-success">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card  o-hidden my-5">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <div class="h1 text-success mb-4"><b>Welcome</b></div>
                                    </div>
                                    <form action=""class="user"method="post">
                                        <div class="card my-2 border-0">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-2"></div>
                                                        <div class="form-group col-md-8">
                                                            <input type="email" class="form-control "
                                                            id="exampleInputEmail" aria-describedby="emailHelp"
                                                            placeholder="Enter Email Address..." name="email">
                                                        </div>
                                                        <div class="col-md-2"></div>
                                                        <div class="col-md-2"></div>
                                                        <div class="form-group col-md-8">
                                                            <input type="password" class="form-control"
                                                                id="exampleInputPassword" placeholder="Password"name="password">
                                                        </div>
                                                        <div class="col-md-4"></div>
                                                        <div class="col-md-4">
                                                        
                                                        <button type="submit" class="btn btn-success btn-block" name="login">Login</button>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a class="small" href="#">Forgot Password?</a>
                                                </div>
                                                <div class="text-center">
                                                    <a class="small" href="Register1.php">Create an Account!</a>
                                                </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>




     <!-- Bootstrap core JavaScript-->
     <script src="vendor/jquery/jquery.min.js"></script>
     <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 
     <!-- Core plugin JavaScript-->
     <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
 
     <!-- Custom scripts for all pages-->
     <script src="js/sb-admin-2.min.js"></script>
    
</body>
</html>