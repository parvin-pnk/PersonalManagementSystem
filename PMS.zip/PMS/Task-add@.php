<?php
    session_start();
    require "dbconn.php";
    

    if(isset($_POST['add-task'])){
        $date=mysqli_real_escape_string($conn,$_POST['task-date']);
        $time=mysqli_real_escape_string($conn,$_POST['task-time']);
        $scheme=mysqli_real_escape_string($conn,$_POST['task-scheme']);
        $task=mysqli_real_escape_string($conn,$_POST['task']);
        $description=mysqli_real_escape_string($conn,$_POST['task-description']);
    
    $query="INSERT INTO task_add(date,time,scheme,task,description) VALUES('$date','$time','$scheme','$task','$description')";
    $check=mysqli_query($conn,$query);
    if($check){
        $_SESSION['message']="Successfully Added";
        header("Location:Task-add.php");
        exit(0);
    }
    else{
        $_SESSION['message']="Not Added Try Again";
        header("Location:Task-add.php");
        exit(0);
    }
    }











?>